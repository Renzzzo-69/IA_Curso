import pickle
import keras
import sklearn
import pandas
import matplotlib
import numpy
import scipy
#from sqlalchemy import true
#from sympy import N
from game import Directions
from game import Agent
from game import Actions

import random

from pacman_extraeFeatures import obtenerFeatures

# Importando librerías para ML
# requiere haber instalado (sugerencia: usar pip): scipy, numpy, matplotlib, pandas,
# sklearn, keras, tensorflow

# version de Python
import sys
print('Python: {}'.format(sys.version))
# scipy
print('scipy: {}'.format(scipy.__version__))
# numpy
print('numpy: {}'.format(numpy.__version__))
# matplotlib
print('matplotlib: {}'.format(matplotlib.__version__))
# pandas
print('pandas: {}'.format(pandas.__version__))
# scikit-learn
print('sklearn: {}'.format(sklearn.__version__))
# keras
print('keras: {}'.format(keras.__version__))
# pickle

# Fin de importación de


class my_ML_Agent(Agent):
    """
    This is a behaviour clonned agent!
    """

    def __init__(self):
        import pickle
        import numpy as np

        # open a file, where you stored the pickled data
        file_modeloCargado = open('modeloEntrenado.p', 'rb')

        # load information from that file
        self.modelo = pickle.load(file_modeloCargado)

        # close the file
        file_modeloCargado.close()

        self.cantAccionesInvalidas = 0

        self.lastAction = None
        self.listActions = []
        self.count = 2          #cantidad de movimientos para comparar

    def getAction(self, state):
        """
        Returns the next action in the path chosen earlier (in
        registerInitialState).  Return Directions.STOP if there is no further
        action to take.

        state: a GameState object (pacman.py)
        """
        features = obtenerFeatures(state).reshape(1, -1)
        
        # Si es un DecisionTreeClassifier
        accionNum = self.modelo.predict(features)
        #print("Accion num: ",accionNum)
        prob_accionNum = self.modelo.predict_proba(features)[0]
        #print("Accion num prob: ",prob_accionNum)

        # Si es un keras sequential
        #accionNum = self.modelo.predict(features).argmax(axis=-1)

        actions = [
            Directions.STOP,
            Directions.EAST,
            Directions.NORTH,
            Directions.WEST,
            Directions.SOUTH
        ]

        legal = state.getLegalActions()

        # De los posibles movimientos predichos por el modelo, se descarta
        #  el movimiento STOP debido a que se requiere que el agente pacman 
        #  este en movimiento, ya que es más util. Solo se colocará STOP 
        #  cuando todos los otros posibles movimientos sean inválidos.
        prob_accionNum[0] = 0.01   #se considero colocar 0.1

        # Coloca como probabilidad 0, las acciones que no sean validas
        for mov in actions:
          if mov not in legal:
            prob_accionNum[actions.index(mov)] = 0
          if len(self.listActions) > 2 and  mov != Directions.STOP:
            prob_accionNum[self.opuesto(self.listActions[-1])] = 0.02

        print("Accion num prob: ",prob_accionNum)
        # Se obtiene la acción que tiene más probabilidad
        action = actions[numpy.argmax(prob_accionNum)]

        # # Se recorre por todas las posibles acciones según la probabilidad obtenida
        # while action not in legal:
        #   # Si entra en while significa que no es valido, aumenta variable + 1
        #   self.cantAccionesInvalidas += 1

        #   # Se coloca en probabilidad 0 la acción inválida
        #   prob_accionNum[numpy.argmax(prob_accionNum)] = 0
          
        #   # Se coloca menor probabilidad al opuesto para evitar bucles
        #   #print(action)
        #   #print(self.opuesto(action))
        #   prob_accionNum[self.opuesto(self.listActions[-1])] = 0.02

        #   # Se obtiene la nueva acción con más probabilidad
        #   action = actions[numpy.argmax(prob_accionNum)]

        # if len(self.listActions) > self.count*4:
        #   if self.isInBucle() and action == self.listActions[-2]:
        #     legal.pop(legal.index(action))
        #     legal.pop(legal.index(Directions.STOP))
        #     legal.append(Directions.STOP)
        #     try: 
        #       legal.pop(legal.index(actions[self.opuesto(action)]))
        #     except:
        #       print("Se trato de eliminar el opuesto, pero no es válido")
            
        #     action = legal[0]

        # Se agrega el movimiento a una lista de los movimientos,
        # se puede usar para verificar si entra en bucle de movimientos.
        self.listActions.append(action)

        print("Features:", features, "Action:", int(accionNum), action)
        print("Mov. inválidos: ",self.cantAccionesInvalidas)
        return action

    def opuesto(self,i_action):
        actions = [
            Directions.EAST,
            Directions.NORTH,
            Directions.WEST,
            Directions.SOUTH
        ]

        # Se obtiene el opuesto
        o_action = (actions.index(i_action)+2)%4
        # Se retorna la posicion + 1
        return o_action + 1 

    def isInBucle(self):
        if self.listActions[-self.count:] == self.listActions[-2*self.count:-self.count] and len(set(self.listActions[-self.count:]))>1:
          return True
        else:
          return False